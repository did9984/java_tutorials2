package 숙제0117_2;

public class TurnOn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PortableNotebook pn = new PortableNotebook();
		pn.writeDocumentation(); //문서
		pn.watchVideo(); //영상
		pn.useApp();  // 사용자 전환
		pn.searchInternet(); //인터넷
	}

}
